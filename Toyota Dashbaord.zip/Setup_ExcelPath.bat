@echo off
REM Double-click once after copying this folder to a new laptop.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup_ExcelPath.ps1"
pause
