# Points the dashboard at Recruitment_Data.xlsx in THIS folder.
# Run once after copying the folder to a new laptop (double-click Setup_ExcelPath.bat).
$here  = Split-Path -Parent $MyInvocation.MyCommand.Path
$excel = Join-Path $here 'Recruitment_Data.xlsx'
$tmdl  = Join-Path $here 'RecruitmentDashboard.SemanticModel\definition\expressions.tmdl'

if (-not (Test-Path $excel)) { Write-Host "ERROR: Recruitment_Data.xlsx not found in $here" -ForegroundColor Red; exit 1 }
if (-not (Test-Path $tmdl))  { Write-Host "ERROR: RecruitmentDashboard.SemanticModel folder not found in $here" -ForegroundColor Red; exit 1 }

$text = [IO.File]::ReadAllText($tmdl)
$new  = [regex]::Replace($text, 'expression FilePath = ".*?"', { param($m) 'expression FilePath = "' + $excel + '"' })
[IO.File]::WriteAllText($tmdl, $new, (New-Object Text.UTF8Encoding $false))

Write-Host ""
Write-Host "Done. Dashboard will read:" -ForegroundColor Green
Write-Host "   $excel"
Write-Host ""
Write-Host "Next: open RecruitmentDashboard.pbip, click Home > Refresh, then Ctrl+S."
